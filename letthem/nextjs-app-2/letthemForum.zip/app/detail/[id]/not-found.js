export default function NotFound() {
  return <h4>404 없는 페이지임</h4>;
}
